# -*- coding: utf-8 -*-
"""
Created on Fri Jan  4 00:33:01 2019

@author: RTR
"""
import numpy as np

def login():
    '''login function'''
    while True:
        username = str(input("Enter a name: "))
        try:
            password = int(input("Enter your password: ")) 
        except:
            print("Please enter numbers only in password")  
            continue
        break
login()  


items = []
quantity = []
goods = ["bread", "egg", "cereals", "oats"]
prices = [2, 3, 4, 5]
cost_by_item = []
def additems(*arguments):
    '''has to add inputs to a list u----- remember it '''    
    b = "yes" 
    c = "no" 
    while True:
        a = input("Yes to add items: ")
        if a in b:
           i = input("Enter the items needed 0 for bread, 1 for egg, 2 for cereal, 3 for oats: ")
           if i == "0":
               items.append(goods[0])
               cost_by_item.append(prices[0])
           if i == "1":
               items.append(goods[1])
               cost_by_item.append(prices[1])
           if i == "2":
               items.append(goods[2])
               cost_by_item.append(prices[2])
           if i == "3":
               items.append(goods[3])
               cost_by_item.append(prices[3])
           if i not in["0", "1", "2", "3"]:
               #print("Invalid input")
               print("Enter correct items") 
               continue
           q = int(input("Enter the quantity: "))
           quantity.append(q)
           print(items,quantity)
           
        if a in c:
            break
additems()

b = 'yes'
c = 'no' 
while True:
    a = input("Card Payment Yes or No: ")
    if a in b :
        def card_ver(name, number, ccv):   
            '''card verification function'''
            pass
        card_ver(input("Enter your name: "), input("Enter your card number: "), input("Enter your ccv: "))    
        break
    if a in c:
        #print("No card")
        break

print("Item Quantity Price Total")

for item, quant, cost  in zip(items,quantity,cost_by_item):
    t=[cost*quant for cost,quant in zip(cost_by_item,quantity)]
    #print(t)
for item, quant, cost,total  in zip(items,quantity,cost_by_item,t):
    print(item,quant,cost,total)


tt = np.array(t)
print("Total Bill Amount",tt.sum())

items.clear()
quantity.clear()
cost_by_item.clear()
